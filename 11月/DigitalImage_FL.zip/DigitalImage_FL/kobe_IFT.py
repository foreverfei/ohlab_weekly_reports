from operator import ilshift
from kobe_FFT import  FFT
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
from kobe_FFT import FFT

def IFT(mid_reult : np.ndarray ) :

    #傅里叶逆变换
    ilshift = np.fft.ifftshift(mid_reult)
    iimg = cv.idft(ilshift)

    res = cv.magnitude(iimg[:, :, 0], iimg[:, :, 1])


    return res




if __name__ == '__main__':

    IFT(FFT('img.png') , 122)