from os import umask

import kobe_FFT,kobe_IFT
import numpy as np
import matplotlib.pyplot as plt
import cv2
import os

#给原图像增加噪声,这里选用了一种椒盐噪声,这样平滑后结果会更加直观
def Salt_pepper( pp = 0.1, ps = 0.1) :

    origin_image_path = 'img.png'
    img = cv2.imread(origin_image_path ,0)
    rows, cols = img.shape

    mask = np.random.choice((0, 0.5, 1), size=(rows, cols), p=[pp, (1 - ps - pp), ps])

    img_copy = img.copy()
    #确定洒椒or盐
    img_copy[mask == 1] = 255
    img_copy[mask == 0] = 0
    cv2.imwrite('img_1.png', img_copy)



def high_pass (pre_img , rows ,cols)  :

    c_rows , c_cols = rows//2 , cols//2

    pre_img[c_rows - 50:c_rows + 50 , c_cols - 50:c_cols + 50] = 0

    return pre_img

def low_pass (pre_img , rows ,cols) :

    c_rows , c_cols = rows//2 , cols//2

    mask  = np.zeros((rows, cols, 2) , np.uint8)
    mask[c_rows - 100:c_rows + 100 , c_cols - 100:c_cols + 100] = 1

    return mask * pre_img

def Gs_smoothing (img) :

    for i in range (10) :
        img = cv2.GaussianBlur(img,(7,7),0)

    return img


if __name__ == '__main__':

    Salt_pepper()

    image = cv2.imread('img_1.png',0)
    image_path = 'img_1.png'
    img_for_Gs = cv2.imread(image_path ,0)

    origin_image , fft_result ,rows, cols= kobe_FFT.FFT('img.png')

    high_result = high_pass(fft_result , rows, cols)
    low_result = low_pass(fft_result , rows, cols)

    res_1 = kobe_IFT.IFT(high_result)
    res_2 = kobe_IFT.IFT(low_result)
    res_3 = Gs_smoothing(img_for_Gs)

    plt.subplot(151), plt.imshow(origin_image, 'gray'), plt.title('Original')
    plt.axis('off')  #原图
    plt.subplot(152), plt.imshow(image, 'gray'), plt.title('Noise')
    plt.axis('off')  #加噪声后
    plt.subplot(153), plt.imshow(res_1, 'gray'), plt.title('Result_high')
    plt.axis('off')   #高通
    plt.subplot(154), plt.imshow(res_2, 'gray'), plt.title('Result_low')
    plt.axis('off')   #低通
    plt.subplot(155), plt.imshow(res_3, 'gray'), plt.title('Result_GS')
    plt.axis('off')   #平滑
    plt.show()
