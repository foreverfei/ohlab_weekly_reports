import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt

''' 
应用离散傅里叶变换（DFT）：
    cv.dft计算输入图像的傅里叶变换，获得频域表示。
    np.float32(img)
    将图像转换为float32类型，因为DFT对实数输入的处理效果最好。
    flags = cv.DFT_COMPLEX_OUTPUT指定输出应为复数矩阵，包含实部和虚部
'''

def FFT(image_path : str) :


    img = cv.imread(image_path, 0)  #转化为单通道灰度图像

    rows, cols = img.shape

    # 傅里叶变换
    dft = cv.dft(np.float32(img), flags=cv.DFT_COMPLEX_OUTPUT)  #指定输出应为复数矩阵，包含实部和虚部

    # 将频谱低频从左上角移动至中心位置 使得零频率成分（直流成分）位于数组的中心位置
    dft_shift = np.fft.fftshift(dft)
    # print(dft_shift)


    return [img,dft_shift , rows , cols]

if __name__ == '__main__':

    fft_result = FFT('img.png')



